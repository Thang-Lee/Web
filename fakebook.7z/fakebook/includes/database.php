<?php
$con = mysqli_connect('localhost','root','','fakebook');
if(mysqli_errno($con))
{
	echo "<script> alert('Cannot connected data'</script>)";
}
?>
