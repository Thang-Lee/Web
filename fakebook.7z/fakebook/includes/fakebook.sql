-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2021 at 07:26 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fakebook`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(100) NOT NULL,
  `post_id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `content_comment` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `created` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `post_id`, `user_id`, `name`, `content_comment`, `image`, `created`) VALUES
(24, '12', '5', 'scf sourcecode', 'hehe', 'upload/world2.png', '1607671215'),
(25, '12', '2', 'test2 daumoi', 'mua code ung ho sinh vien ngheo di moi nguoi', 'upload/11.jpg', '1607671417'),
(26, '12', '1', 'test1 khabank', '@test2 daumoi: noi dung day moi nguoi', 'upload/7.png', '1607671989'),
(27, '12', '3', 'test3 huanrose', '@test1 khabank: co lam thi moi co an', 'upload/8.png', '1607672101');

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `photo_id` int(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `date_added` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`photo_id`, `location`, `user_id`, `date_added`) VALUES
(1, 'upload/fake.jpg', '1', '2020-12-11'),
(2, 'upload/11.jpg', '2', '2020-12-11'),
(11, 'upload/fake.png', '5', '2020-12-11 14:38:06'),
(12, 'upload/8.png', '3', '2020-12-11 14:39:07');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `post_image` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `created` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `user_id`, `post_image`, `content`, `created`) VALUES
(12, '5', 'upload/sourcecodefree.png', 'test admin', '1607671207'),
(13, '2', 'upload/11.jpg', 'test dau moi', '1607671395'),
(14, '4', 'upload/th.jpg', 'Tin HOT trong ngÃ y', '1607671484'),
(15, '1', 'upload/7.png', 'test kha bank\r\nchao moi nguoi nha, 10 nam nua gap nhau', '1607671955'),
(16, '3', 'upload/8.png', 'test huanrose\r\n1. co lam thi moi co an\r\n2. chao ae thai nguyen\r\n', '1607672079'),
(17, '5', 'upload/world3.png', 'vote fakebook or facebook ?\r\n', '1607672228'),
(18, '5', 'upload/fakebook.jpg', 'fakebook la so 1 ', '1607672257');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `username2` varchar(100) NOT NULL,
  `birthday` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `email2` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `password2` varchar(100) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `cover_picture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `firstname`, `lastname`, `username`, `username2`, `birthday`, `gender`, `number`, `email`, `email2`, `password`, `password2`, `profile_picture`, `cover_picture`) VALUES
(1, 'test1', 'khabank', 'kha bank', '1', '13/November/1995', 'male', '123', 'khabank@gmail.com', 'test1@gmail.com', '12345', '12345', 'upload/7.png', 'upload/fakebook1.png'),
(2, 'test2', 'daumoi', 'dau moi', '2', '1995-11-13', 'Male', '1234', 'daumoi@gmail.com', 'test2@gmail.com', '123456', '123456', 'upload/11.jpg', 'upload/fakebook.jpg'),
(3, 'test3', 'huanrose', 'huan rose', '3', '14/June/1996', 'female', '12345', 'huanrose@gmail.com', 'test3@gmail.com', '1234567', '1234567', 'upload/8.png', 'upload/fake.png'),
(4, 'test4', 'tinHOT', 'tin HOT', '4', '1/January/1901', 'female', '123456', 'tinhot@gmail.com', 'test4@gmail.com', '12345678', '12345678', 'upload/unnamed.jpg', 'upload/world2.png'),
(5, 'scf', 'sourcecode', 'admin', 'admin', '1/January/1901', 'male', '0968356677', 'sourcecodefree.org@gmail.com', 'sourcecodefree.org@gmail.com', 'admin', 'admin', 'upload/world2.png', 'upload/fake.jpg'),
(6, 'thang', 'thang', 'thang', 'thang', '1/January/1901', 'male', '123', 'thanglee@gmail.com', 'thanglee@gmail.com', '123', '123', 'upload/fake.jpg', 'upload/fake.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`photo_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `photo_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
